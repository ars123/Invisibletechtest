 Weather Application


Remember to execute ```npm install``` to install libraries


### Example:
```
node app -d "Cali Colombia"
```